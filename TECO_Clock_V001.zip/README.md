
TECO Clock_V001 - Flutter project (source)

How to build:
1. Install Flutter SDK (recommended stable 3.24.x)
2. Unzip this folder.
3. From project root run:
   flutter pub get
   flutter run   # to run on connected device (debug)
   flutter build apk --release  # to build release APK

Notes:
- The app sends UDP ASCII packets to the configured IP and port (default 192.168.4.1:2000).
- Packet format: YYYY MM DD D HH MM SS A BB (no spaces) where:
  - YYYY = year (4 digits)
  - MM = month (2 digits)
  - DD = day (2 digits)
  - D = weekday (1..7, Monday=1 .. Sunday=7)
  - HH = hour (2 digits, 24-hour)
  - MM = minute (2 digits)
  - SS = second (2 digits)
  - A = AM(1) or PM(2) based on hour (1 if hour<12 else 2)
  - BB = brightness 01..15 (2 digits)
- The weekday mapping follows ISO weekday (Monday=1 .. Sunday=7). If your device expects a different mapping, modify lib/main.dart `_computeWeekdayDigit`.
- Settings dialog allows changing IP, port, gateway and subnet (saved in SharedPreferences).

Limitations:
- This archive contains the Flutter source only. It does NOT include a prebuilt APK because building requires the Flutter SDK / Android toolchain locally.
- If you need the APK and cannot build locally, let me know and I can provide guidance or CI steps to build it for you.

