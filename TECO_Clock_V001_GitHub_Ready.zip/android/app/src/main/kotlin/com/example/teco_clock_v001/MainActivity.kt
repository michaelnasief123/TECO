
package com.example.teco_clock_v001

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
